var openDetailRow = null;

function sortTable(col) {
    var table = document.querySelector("table");
    if (!table) return;
    var tbody = table.tBodies[0];
    var rows = Array.prototype.slice.call(tbody.rows);
    var asc = table.dataset.col == col && table.dataset.dir == "asc" ? false : true;

    rows.sort(function(a, b) {
        var A = a.cells[col].innerText.replace("%", "").replace(/:/g, "");
        var B = b.cells[col].innerText.replace("%", "").replace(/:/g, "");
        var nA = parseFloat(A), nB = parseFloat(B);
        if (!isNaN(nA) && !isNaN(nB)) return asc ? nA - nB : nB - nA;
        return asc ? a.cells[col].innerText.localeCompare(b.cells[col].innerText)
                   : b.cells[col].innerText.localeCompare(a.cells[col].innerText);
    });

    rows.forEach(function(r) { tbody.appendChild(r); });
    table.dataset.col = col;
    table.dataset.dir = asc ? "asc" : "desc";
    applyAlerts();
}

function applyAlerts() {
    var table = document.querySelector("table");
    if (!table) return;
    var headers = Array.prototype.slice.call(table.tHead.rows[0].cells).map(function(h) { return h.innerText.trim(); });
    var colIndex = headers.findIndex(function(h) { return h.toLowerCase() === "% erro"; });
    if (colIndex === -1) return;
    Array.prototype.slice.call(table.tBodies[0].rows).forEach(function(row) {
        var cell = row.cells[colIndex];
        if (!cell) return;
        var val = parseFloat(cell.innerText.replace("%", "").trim());
        row.classList.remove("alert", "warn");
        if (!isNaN(val)) {
            if (val >= 80) row.classList.add("alert");
            else if (val >= 50) row.classList.add("warn");
        }
    });
}

function attachHeaderHandlers() {
    var headers = Array.prototype.slice.call(document.querySelectorAll("thead th.js-sort"));
    headers.forEach(function(th) {
        th.addEventListener("click", function() {
            var col = parseInt(th.getAttribute("data-col"), 10);
            if (!isNaN(col)) sortTable(col);
        });
    });
}

function renderHistoryTable(hist) {
    if (!hist || !hist.length) return "<div>Sem dados</div>";
    var rowsHtml = "";
    for (var i = 0; i < hist.length; i++) {
        var h = hist[i];
        rowsHtml += "<tr data-error='" + (h.erro ? "1" : "0") + "'>" +
                    "<td>" + (h.data || "--") + "</td>" +
                    "<td>" + (h.vel || "--") + "</td>" +
                    "<td>" + (h.giro || "--") + "</td>" +
                    "<td class='" + (h.erro ? "media-err" : "") + "'>" + (h.media || "--") + "</td>" +
                    "</tr>";
    }
    return "<table>" +
           "<thead><tr><th>Data Hora</th><th>Vel</th><th>Giro</th><th>Média</th></tr></thead>" +
           "<tbody>" + rowsHtml + "</tbody>" +
           "</table>";
}

function createDetailRow(row) {
    var rowId = row.dataset.rowId;
    var hist = JSON.parse(row.dataset.history || "[]");
    var mapId = "detail-map-" + rowId;

    var detail = document.createElement("tr");
    detail.className = "detail-row";
    detail.dataset.parentRow = rowId;
    detail.innerHTML =
        "<td colspan='" + row.cells.length + "'>" +
            "<div class='detail-wrap'>" +
                "<div class='detail-header'></div>" +
                "<div class='detail-grid'>" +
                    "<div class='detail-table-wrap'>" +
                        renderHistoryTable(hist) +
                    "</div>" +
                    "<div class='detail-map' id='" + mapId + "'></div>" +
                "</div>" +
            "</div>" +
        "</td>";
    return detail;
}

function initDetailMap(mapEl, lat, lon) {
    var map = L.map(mapEl, { zoomControl: true, attributionControl: false });
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19 }).addTo(map);

    if (!isNaN(lat) && !isNaN(lon)) {
        var pos = [lat, lon];
        L.marker(pos).addTo(map);
        map.setView(pos, 14);
    } else {
        map.setView([-23.3103, -51.1628], 5);
    }
    setTimeout(function() { map.invalidateSize(); }, 0);
}

function toggleDetailForRow(row) {
    var existing = row.nextElementSibling;
    if (existing && existing.classList.contains("detail-row")) {
        existing.remove();
        row.classList.remove("expanded");
        openDetailRow = null;
        localStorage.removeItem("radar_open_row");
        return;
    }

    if (openDetailRow && openDetailRow !== row) {
        var openDetail = openDetailRow.nextElementSibling;
        if (openDetail && openDetail.classList.contains("detail-row")) {
            openDetail.remove();
        }
        openDetailRow.classList.remove("expanded");
    }

    var detail = createDetailRow(row);
    if (row.parentNode) {
        row.parentNode.insertBefore(detail, row.nextSibling);
    }
    row.classList.add("expanded");
    openDetailRow = row;
    if (row.dataset.rowId) {
        localStorage.setItem("radar_open_row", row.dataset.rowId);
    }
    detail.dataset.errIndex = "0";

    var mapEl = detail.querySelector(".detail-map");
    var lat = parseFloat(row.dataset.lat);
    var lon = parseFloat(row.dataset.lon);
    if (mapEl && typeof L !== "undefined") {
        initDetailMap(mapEl, lat, lon);
    }
}

function scrollToNextError(detailRow) {
    var wrap = detailRow.querySelector(".detail-table-wrap");
    if (!wrap) return;
    var errors = Array.prototype.slice.call(wrap.querySelectorAll("tr[data-error='1']"));
    if (!errors.length) return;
    var idx = parseInt(detailRow.dataset.errIndex || "0", 10);
    if (isNaN(idx) || idx < 0 || idx >= errors.length) idx = 0;
    var target = errors[idx];
    var top = target.offsetTop - wrap.clientHeight / 2;
    wrap.scrollTop = top;
    target.classList.add("err-flash");
    setTimeout(function() { target.classList.remove("err-flash"); }, 1200);
    detailRow.dataset.errIndex = String((idx + 1) % errors.length);
}

function attachRowHandlers() {
    var rows = Array.prototype.slice.call(document.querySelectorAll("tbody tr"));
    rows.forEach(function(row, idx) {
        if (!row.dataset.rowId || row.dataset.rowId === "") {
            row.dataset.rowId = String(idx + 1);
        }
        row.addEventListener("click", function() { toggleDetailForRow(row); });
        var icon = row.querySelector(".err-icon");
        if (icon) {
            icon.addEventListener("click", function(ev) {
                ev.stopPropagation();
                if (icon.getAttribute("data-disabled") === "1") return;
                if (!row.nextElementSibling || !row.nextElementSibling.classList.contains("detail-row")) {
                    toggleDetailForRow(row);
                }
                var detail = row.nextElementSibling;
                if (detail && detail.classList.contains("detail-row")) {
                    scrollToNextError(detail);
                }
            });
        }
    });
}

function normalize(v) {
    return (v || "").toString().toLowerCase().trim();
}

function filterByVehicle(value) {
    var rows = Array.prototype.slice.call(document.querySelectorAll("tbody tr"));
    var q = normalize(value);
    var statusFilter = normalize(localStorage.getItem("radar_status_filter") || "todos");
    var garagemFilter = normalize(localStorage.getItem("radar_garagem_filter") || "todos");
    rows.forEach(function(row) {
        var veic = row.dataset.veiculo || "";
        var st = normalize(row.dataset.status || "");
        var inGaragem = normalize(row.dataset.garagem || "false");
        var okText = !q || normalize(veic).indexOf(q) !== -1;
        var okStatus = statusFilter === "todos" ||
            (statusFilter === "movimento" && st.indexOf("movimento") !== -1) ||
            (statusFilter === "parado" && st.indexOf("parado") !== -1);
        var okGaragem = garagemFilter === "todos" ||
            (garagemFilter === "garagem" && inGaragem === "true") ||
            (garagemFilter === "fora" && inGaragem !== "true");
        row.style.display = (okText && okStatus && okGaragem) ? "" : "none";
    });
}

function setTheme(mode) {
    if (mode === "system") {
        document.documentElement.removeAttribute("data-theme");
    } else {
        document.documentElement.setAttribute("data-theme", mode);
    }
    localStorage.setItem("radar_theme", mode);
}

function setStatusFilter(mode) {
    localStorage.setItem("radar_status_filter", mode);
    var input = document.getElementById("vehicle-filter");
    filterByVehicle(input ? input.value : "");
}

function setGaragemFilter(mode) {
    localStorage.setItem("radar_garagem_filter", mode);
    var input = document.getElementById("vehicle-filter");
    filterByVehicle(input ? input.value : "");
}

document.addEventListener("DOMContentLoaded", function() {
    applyAlerts();
    attachHeaderHandlers();
    var saved = localStorage.getItem("radar_theme") || "system";
    var themeToggle = document.getElementById("theme-toggle");
    if (themeToggle) {
        themeToggle.dataset.mode = saved;
        setTheme(saved);
        updateThemeToggle(themeToggle, saved);
        themeToggle.addEventListener("click", function() {
            var mode = themeToggle.dataset.mode || "system";
            var next = mode === "system" ? "light" : (mode === "light" ? "dark" : "system");
            themeToggle.dataset.mode = next;
            setTheme(next);
            updateThemeToggle(themeToggle, next);
        });
    } else {
        setTheme(saved);
    }
    attachRowHandlers();

    var savedStatus = localStorage.getItem("radar_status_filter") || "todos";
    var statusSel = document.getElementById("status-filter");
    if (statusSel) {
        statusSel.value = savedStatus;
        statusSel.addEventListener("change", function() { setStatusFilter(statusSel.value); });
    }

    var savedGaragem = localStorage.getItem("radar_garagem_filter") || "todos";
    var garagemSel = document.getElementById("garagem-filter");
    if (garagemSel) {
        garagemSel.value = savedGaragem;
        garagemSel.addEventListener("change", function() { setGaragemFilter(garagemSel.value); });
    }

    var openId = localStorage.getItem("radar_open_row");
    if (openId) {
        var rows = Array.prototype.slice.call(document.querySelectorAll("tbody tr"));
        for (var i = 0; i < rows.length; i++) {
            if (rows[i].dataset.rowId === openId) {
                toggleDetailForRow(rows[i]);
                break;
            }
        }
    }

    var input = document.getElementById("vehicle-filter");
    if (input) {
        var savedVehicle = localStorage.getItem("radar_vehicle_filter") || "";
        if (savedVehicle) input.value = savedVehicle;
        input.addEventListener("input", function() {
            localStorage.setItem("radar_vehicle_filter", input.value);
            filterByVehicle(input.value);
        });
        filterByVehicle(input.value);
    }

    var lastUpdate = null;
    function checkForUpdates() {
        fetch("/status", { cache: "no-store" })
            .then(function(resp) { return resp.json(); })
            .then(function(data) {
                if (data && data.processando) return;
                var next = data && data.ultima_atualizacao ? data.ultima_atualizacao : null;
                if (!next) return;
                if (lastUpdate && next !== lastUpdate) {
                    location.reload();
                    return;
                }
                lastUpdate = next;
            })
            .catch(function() { /* ignore */ });
    }
    checkForUpdates();
    setInterval(checkForUpdates, 60000);
});

function updateThemeToggle(btn, mode) {
    if (!btn) return;
    btn.classList.remove("theme-system", "theme-light", "theme-dark");
    if (mode === "light") btn.classList.add("theme-light");
    else if (mode === "dark") btn.classList.add("theme-dark");
    else btn.classList.add("theme-system");
    var label = mode === "light" ? "Claro" : (mode === "dark" ? "Escuro" : "Sistema");
    btn.title = "Tema: " + label;
    btn.setAttribute("aria-label", "Tema: " + label);
}


