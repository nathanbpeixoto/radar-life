import os
import time
import threading
import pandas as pd
import re
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from datetime import datetime

# ================= CONFIGURACAO =================
PASTA_CSV = r"C:/Users/nathan.peixoto/OneDrive - VIACAO GARCIA LTDA/4. Londrisul/1. Banco de Dados Gerais/31. BOTS/1. Historico de Rastreaento"
ENCODING = "ISO-8859-1"

# ================= AREA GARAGEM =================
GARAGEM_LAT = -23.304211
GARAGEM_LON = -51.121664
GARAGEM_PERIMETRO_M = 1380.0
GARAGEM_RAIO_M = GARAGEM_PERIMETRO_M / (2 * 3.141592653589793)

resultado_atual = pd.DataFrame()
ultima_atualizacao = "--:--:--"
ultima_atualizacao_iso = ""
processando = False
_ultimo_snapshot = None
_snapshot_lock = threading.Lock()

# ================= FUNCOES AUXILIARES =================
def seg_para_hhmmss(seg):
    seg = int(seg)
    h = seg // 3600
    m = (seg % 3600) // 60
    s = seg % 60
    return f"{h:02}:{m:02}:{s:02}"


def parse_lat_lon(texto):
    if not texto:
        return None, None
    nums = re.findall(r"-?\d+(?:\.\d+)?", str(texto))
    if len(nums) >= 2:
        lat = float(nums[0])
        lon = float(nums[1])
        if -90 <= lat <= 90 and -180 <= lon <= 180:
            return lat, lon
    return None, None


def distancia_m(lat1, lon1, lat2, lon2):
    if None in (lat1, lon1, lat2, lon2):
        return None
    from math import radians, sin, cos, sqrt, atan2
    r = 6371000.0
    dlat = radians(lat2 - lat1)
    dlon = radians(lon2 - lon1)
    a = sin(dlat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return r * c

# ================= PROCESSAMENTO =================
def _snapshot_csvs():
    estado = {}
    try:
        arquivos = os.listdir(PASTA_CSV)
    except:
        return estado

    for arquivo in arquivos:
        if not arquivo.lower().endswith(".csv"):
            continue
        caminho = os.path.join(PASTA_CSV, arquivo)
        try:
            st = os.stat(caminho)
        except:
            continue
        estado[arquivo] = (st.st_mtime_ns, st.st_size)
    return estado


def _houve_mudanca():
    global _ultimo_snapshot
    estado_atual = _snapshot_csvs()
    with _snapshot_lock:
        if _ultimo_snapshot is None:
            _ultimo_snapshot = estado_atual
            return True
        if estado_atual == _ultimo_snapshot:
            return False
        _ultimo_snapshot = estado_atual
    return True


def processar_csvs():
    global resultado_atual, ultima_atualizacao, ultima_atualizacao_iso, processando
    processando = True
    dfs = []

    try:
        for arquivo in os.listdir(PASTA_CSV):
            if arquivo.lower().endswith(".csv"):
                try:
                    df = pd.read_csv(
                        os.path.join(PASTA_CSV, arquivo),
                        encoding=ENCODING,
                        dtype=str
                    )
                    dfs.append(df)
                except:
                    pass

        if not dfs:
            return

        df = pd.concat(dfs, ignore_index=True)

        # Conversoes
        df["Data"] = pd.to_datetime(df["Data"], errors="coerce")
        df["Vel"] = pd.to_numeric(df["Vel"], errors="coerce").fillna(0)
        df["Giro"] = pd.to_numeric(df["Giro"], errors="coerce").fillna(0)
        df["Média"] = pd.to_numeric(df["Média"], errors="coerce").fillna(0)

        # Deduplicacao
        df = df.drop_duplicates(subset=["VEICULO", "Data"])
        df = df.sort_values(["VEICULO", "Data"])

        # Regras de negocio
        df["EM_MOVIMENTO"] = (df["Vel"] > 0)
        df["ERRO"] = df["EM_MOVIMENTO"] & (df["Média"] == 0)
        df["DELTA_T"] = df.groupby("VEICULO")["Data"].diff().dt.total_seconds().fillna(0)

        # Ultimo registro por veiculo
        ultimo_registro_dt = df.groupby("VEICULO")["Data"].max()
        ultimo_registro = ultimo_registro_dt.dt.strftime("%d/%m/%Y %H:%M:%S")

        # Agrupamento principal (movimento)
        resumo = (
            df[df["EM_MOVIMENTO"]]
            .groupby("VEICULO")
            .agg(
                tempo_mov=("DELTA_T", "sum"),
                tempo_erro=("DELTA_T", lambda x: x[df.loc[x.index, "ERRO"]].sum())
            )
        )

        # Garantir que todos os veiculos aparecam, mesmo parados
        todos_veiculos = ultimo_registro_dt.index
        resumo = resumo.reindex(todos_veiculos)

        resumo["tempo_mov"] = resumo["tempo_mov"].fillna(0)
        resumo["tempo_erro"] = resumo["tempo_erro"].fillna(0)
        resumo["%_ERRO_NUM"] = resumo.apply(
            lambda r: (r["tempo_erro"] / r["tempo_mov"]) * 100 if r["tempo_mov"] > 0 else 0,
            axis=1
        )
        resumo["% Erro"] = resumo["%_ERRO_NUM"].round(2).astype(str) + "%"

        # Blocos consecutivos de erro
        df["BLOCO"] = (df["ERRO"] != df.groupby("VEICULO")["ERRO"].shift()).cumsum()

        tempo_medio = (
            df[df["ERRO"]]
            .groupby(["VEICULO", "BLOCO"])["DELTA_T"]
            .sum()
            .groupby("VEICULO")
            .mean()
        )

        resumo["Tempo Médio Consecutivo"] = tempo_medio.fillna(0).apply(seg_para_hhmmss)
        resumo["Tempo de Movimentação"] = resumo["tempo_mov"].apply(seg_para_hhmmss)
        resumo["Tempo Total Erro"] = resumo["tempo_erro"].apply(seg_para_hhmmss)
        resumo["Ult. Registro de Rastreamento"] = ultimo_registro

        resultado_base = (
            resumo
            .sort_values("tempo_erro", ascending=False)
            .reset_index()
            [[
                "VEICULO",
                "Tempo de Movimentação",
                "% Erro",
                "Tempo Médio Consecutivo",
                "Tempo Total Erro",
                "Ult. Registro de Rastreamento"
            ]]
        )

        # Historico completo, status, garagem e dados de mapa
        hist_por_veiculo = {}
        lat_por_veiculo = {}
        lon_por_veiculo = {}
        status_por_veiculo = {}
        garagem_por_veiculo = {}

        df_ordenado = df.sort_values(["VEICULO", "Data"])
        col_local = "Localização" if "Localização" in df.columns else None
        col_endereco = "Endereço/Localização" if "Endereço/Localização" in df.columns else None

        for veiculo, ultimo_dt in ultimo_registro_dt.items():
            if pd.isna(ultimo_dt):
                continue
            recortes = df_ordenado[
                (df_ordenado["VEICULO"] == veiculo) &
                (df_ordenado["Data"] <= ultimo_dt)
            ].sort_values("Data", ascending=False)

            hist = []
            for _, r in recortes.iterrows():
                when = r["Data"].strftime("%d/%m %H:%M:%S") if pd.notna(r["Data"]) else "--/-- --:--:--"
                vel_val = float(r.get("Vel", 0) or 0)
                media_val = float(r.get("Média", 0) or 0)
                erro = (vel_val > 0) and (media_val == 0)
                hist.append({
                    "data": when,
                    "vel": str(r.get("Vel", "")).strip(),
                    "giro": str(r.get("Giro", "")).strip(),
                    "media": str(r.get("Média", "")).strip(),
                    "erro": erro
                })
            hist_por_veiculo[veiculo] = hist

            if len(recortes) > 0:
                r0 = recortes.iloc[0]
                status_por_veiculo[veiculo] = "Em movimento" if float(r0.get("Vel", 0) or 0) > 0 else "Parado"
                lat, lon = parse_lat_lon(r0[col_local]) if col_local else (None, None)
                if lat is None or lon is None:
                    lat, lon = parse_lat_lon(r0[col_endereco]) if col_endereco else (None, None)
                lat_por_veiculo[veiculo] = lat
                lon_por_veiculo[veiculo] = lon
                dist = distancia_m(lat, lon, GARAGEM_LAT, GARAGEM_LON)
                garagem_por_veiculo[veiculo] = bool(dist is not None and dist <= GARAGEM_RAIO_M)
            else:
                status_por_veiculo[veiculo] = "Sem dados"
                garagem_por_veiculo[veiculo] = False

        resultado_base["__hist"] = resultado_base["VEICULO"].map(lambda v: hist_por_veiculo.get(v, []))
        resultado_base["__lat"] = resultado_base["VEICULO"].map(lambda v: lat_por_veiculo.get(v))
        resultado_base["__lon"] = resultado_base["VEICULO"].map(lambda v: lon_por_veiculo.get(v))
        resultado_base["__status"] = resultado_base["VEICULO"].map(lambda v: status_por_veiculo.get(v, "Sem dados"))
        resultado_base["__garagem"] = resultado_base["VEICULO"].map(lambda v: garagem_por_veiculo.get(v, False))
        resultado_base["__has_error"] = resultado_base["__hist"].map(lambda h: any(r.get("erro") for r in h))

        resultado_atual = resultado_base
        agora = datetime.now()
        ultima_atualizacao = agora.strftime("%H:%M:%S")
        ultima_atualizacao_iso = agora.isoformat()
    finally:
        processando = False


def processar_csvs_se_mudou():
    if _houve_mudanca():
        processar_csvs()

# ================= WATCHDOG =================
class MonitorPasta(FileSystemEventHandler):
    def on_created(self, event):
        if not event.is_directory and event.src_path.lower().endswith(".csv"):
            time.sleep(2)
            processar_csvs_se_mudou()

    def on_modified(self, event):
        if not event.is_directory and event.src_path.lower().endswith(".csv"):
            time.sleep(2)
            processar_csvs_se_mudou()

    def on_moved(self, event):
        dest = getattr(event, "dest_path", "")
        if not event.is_directory and dest.lower().endswith(".csv"):
            time.sleep(2)
            processar_csvs_se_mudou()


def iniciar_monitor():
    observer = Observer()
    observer.schedule(MonitorPasta(), PASTA_CSV, recursive=False)
    observer.start()


def iniciar_atualizacao_periodica(intervalo_seg=10):
    while True:
        time.sleep(intervalo_seg)
        processar_csvs_se_mudou()


def start_background_tasks():
    threading.Thread(target=iniciar_monitor, daemon=True).start()
    threading.Thread(target=iniciar_atualizacao_periodica, args=(10,), daemon=True).start()
