from flask import Blueprint, render_template, jsonify
from . import radar

bp = Blueprint("web", __name__)


@bp.route("/")
def home():
    if radar.resultado_atual.empty:
        return "Aguardando arquivos..."
    colunas_visiveis = [
        "VEICULO",
        "Tempo de Movimentação",
        "% Erro",
        "Tempo Médio Consecutivo",
        "Tempo Total Erro",
        "Ult. Registro de Rastreamento"
    ]
    veiculos = sorted(radar.resultado_atual["VEICULO"].dropna().astype(str).unique().tolist())
    return render_template(
        "index.html",
        resultado=radar.resultado_atual,
        atualizacao=radar.ultima_atualizacao,
        colunas_visiveis=colunas_visiveis,
        veiculos=veiculos,
    )


@bp.route("/status")
def status():
    return jsonify({
        "ultima_atualizacao": radar.ultima_atualizacao_iso or "",
        "processando": bool(radar.processando),
    })
